module com.example.kidlearn {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.kidlearn to javafx.fxml;
    exports com.example.kidlearn;
}